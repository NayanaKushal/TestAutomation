package com.weathershopper.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.weathershopper.TestBase.TestBase;

public class CartPage extends TestBase {
	
	  //PageFactory: Object Repo
	   @FindBy(xpath=".//div/table[@class='table table-striped']")
	   WebElement cartItemsList;
	
	   @FindBy(xpath=".//span[text()='Pay with Card']")
	   WebElement payWithCard;
	   
	   
	   
	   //Initialize the pageFactory
	   public CartPage() {
		   PageFactory.initElements(driver, this);
		   
	   }
	   
	   
	   //Actions
	   public void displayListOfCartItems() {
		   
	   List<WebElement> list = driver.findElements(By.xpath("/html/body/div[1]/div[2]/table/tbody/tr"));
	   
	   for(int i=0; i<list.size();i++)
	   {
		   String cartItemNames= list.get(i).getText();
		   System.out.println("list of items in cart page are: " +cartItemNames);
		   
		   payWithCard.click();
	   }
		   
	   }
	   

}
