package com.weathershopper.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.weathershopper.TestBase.TestBase;

public class OrderConfirmationPage extends TestBase{
	
	//PageFactory: Object Repo
	
	@FindBy(xpath="/html/body/div/div[2]/p[@class='text-justify']")
	WebElement orderConfimMessage;
	
	
	
	 //Initialize the page factory
	   public OrderConfirmationPage() {
		   PageFactory.initElements(driver, this);
	   }
	   
	   
	 //Actions
	   public void validateOrderConfMess() throws InterruptedException {
		   
		   String mess= orderConfimMessage.getText();
		   
		   Thread.sleep(3000);
		   
		   System.out.println("The payment message is :"+ mess);
	   }
	   
	   

}
