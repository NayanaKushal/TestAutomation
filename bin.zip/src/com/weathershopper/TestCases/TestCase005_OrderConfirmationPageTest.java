package com.weathershopper.TestCases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.weathershopper.TestBase.TestBase;
import com.weathershopper.pages.CartPage;
import com.weathershopper.pages.HomePage;
import com.weathershopper.pages.OrderConfirmationPage;
import com.weathershopper.pages.PLPPPage;
import com.weathershopper.pages.PaymentPage;

public class TestCase005_OrderConfirmationPageTest extends TestBase {
	
	HomePage homepage;
	PLPPPage plp_page;
	CartPage cartpage;
	PaymentPage paymentpage;
	OrderConfirmationPage orderConfpage;
	
	public TestCase005_OrderConfirmationPageTest() {
		
		super();
	}
	
	
	@BeforeMethod
	public void Setup() throws InterruptedException
	{
		initalization();
		
		homepage= new HomePage();
		
		plp_page=new PLPPPage();
		
		cartpage = new CartPage();
		
		paymentpage = new PaymentPage();
		

		orderConfpage= new OrderConfirmationPage();
	}
	
	
	@Test
	public void orderConfMessTest() throws InterruptedException {
		
        homepage.validateItemSelection();
		
		plp_page.validateAddItemToCart();
		
		cartpage.displayListOfCartItems();
		
		paymentpage.validatePaymentFields();
		
		
		Thread.sleep(3000);
		
		orderConfpage.validateOrderConfMess();
	}
	

	@AfterMethod public void tearDown(){
		  driver.quit(); 
		  
	  }
	 

	
	
}
