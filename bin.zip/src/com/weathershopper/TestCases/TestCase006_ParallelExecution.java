package com.weathershopper.TestCases;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.weathershopper.TestBase.TestBase;
import com.weathershopper.pages.CartPage;
import com.weathershopper.pages.HomePage;
import com.weathershopper.pages.OrderConfirmationPage;
import com.weathershopper.pages.PLPPPage;
import com.weathershopper.pages.PaymentPage;

public class TestCase006_ParallelExecution extends TestBase{ 
	
	HomePage homepage= new HomePage();
	PLPPPage plp_page= new PLPPPage();
	CartPage cartpage= new CartPage();
	PaymentPage paymentpage = new PaymentPage();
	OrderConfirmationPage orderConfpage= new OrderConfirmationPage();


		
		public TestCase006_ParallelExecution() {
			
			super();
		}
		
		@Parameters("browserName")
		@BeforeMethod
		public void setUp(String browserName) {
		
		        System.out.println("Browser name is :"+browserName);
				
				if(browserName.equals("chrome")){
				System.setProperty("webdriver.chrome.driver","D:\\FlinkTest\\WeatherShopperTestAutomation\\Browser\\chromedriver.exe");
				driver = new ChromeDriver(); 
				}
				else if(browserName.equals("FF")){
					System.setProperty("webdriver.gecko.driver","D:\\FlinkTest\\WeatherShopperTestAutomation\\Browser\\geckodriver.exe");	
					driver = new FirefoxDriver(); 
				}
		}
		
		
		@Test
		public void BrowserTest() throws InterruptedException {
		
			
			homepage.validateItemSelection();
			
			plp_page.validateAddItemToCart();
			
			cartpage.displayListOfCartItems();
			
			paymentpage.validatePaymentFields();
			
			
			Thread.sleep(3000);
			
			orderConfpage.validateOrderConfMess();

			}
		

		@AfterMethod public void tearDown()
		{
				driver.quit();
				  
			 }
			 
		
		

	}



