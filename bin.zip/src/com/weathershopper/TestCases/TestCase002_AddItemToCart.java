package com.weathershopper.TestCases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.weathershopper.TestBase.TestBase;
import com.weathershopper.pages.HomePage;
import com.weathershopper.pages.PLPPPage;

public class TestCase002_AddItemToCart extends TestBase{
	HomePage homepage;
	PLPPPage plp_page;
	
	public TestCase002_AddItemToCart() {
		super();
	}
	

	@BeforeMethod
	public void Setup( ) throws InterruptedException
	{
		initalization();
		homepage= new HomePage();
		plp_page= new PLPPPage();
	}

	
	@Test(priority=1)
	public void PLPPageAddItemToCartTest() {
		
		homepage.validateItemSelection();
		
		plp_page.validateAddItemToCart();
	}
	
	
	  @AfterMethod public void tearDown() {
		  
		  driver.quit();
		  
	  }
	 
	

}
