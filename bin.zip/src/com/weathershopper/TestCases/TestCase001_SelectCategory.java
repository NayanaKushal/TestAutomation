package com.weathershopper.TestCases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.weathershopper.TestBase.TestBase;
import com.weathershopper.pages.HomePage;

public class TestCase001_SelectCategory extends TestBase {
	
	HomePage homepage;
	
	public TestCase001_SelectCategory()
	{
		super();
	}
	
	
	@BeforeMethod
	public void Setup() throws InterruptedException
	{
		initalization();
		homepage= new HomePage();
	}
	
	
	
	


	@Test(priority=1)
	public void HomePageCurrentURLTest()
	{
		String url= homepage.validateCurrentURL();
		Assert.assertEquals(url,"https://weathershopper.pythonanywhere.com/");
		
	}
	
	@Test(priority=2)
	 public void HomePageItemSelectionTest() {
		homepage.validateItemSelection();
	}
	
	
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
