package com.weathershopper.TestCases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.weathershopper.TestBase.TestBase;
import com.weathershopper.pages.CartPage;
import com.weathershopper.pages.HomePage;
import com.weathershopper.pages.PLPPPage;

public class TestCase003_CartItems extends TestBase {
	
   HomePage homepage;
   PLPPPage plp_page;
   CartPage cartpage;
   
   public TestCase003_CartItems() {
	   super();
   }
   
   @BeforeMethod
	public void Setup() throws InterruptedException
	{
	   initalization();
	   homepage= new HomePage();
	   plp_page= new PLPPPage();
	   cartpage= new CartPage();
   }
   
   @Test(priority=1)
   public void CartPageListTest() {
	    homepage.validateItemSelection();
		
		plp_page.validateAddItemToCart();
		
		cartpage.displayListOfCartItems();
		
		
   }
   
   
   @AfterMethod
   public void tearDown() {
	   driver.quit();
   }

}
